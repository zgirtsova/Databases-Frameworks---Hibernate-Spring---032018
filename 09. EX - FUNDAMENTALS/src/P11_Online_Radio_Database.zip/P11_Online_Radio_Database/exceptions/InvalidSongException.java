package P11_Online_Radio_Database.exceptions;

public class InvalidSongException extends Exception {
}