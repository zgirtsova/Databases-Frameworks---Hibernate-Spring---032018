package P11_Online_Radio_Database.exceptions;

public class InvalidSongNameException extends InvalidSongException {
}