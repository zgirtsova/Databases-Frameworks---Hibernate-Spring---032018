package P11_Online_Radio_Database.exceptions;

public class InvalidArtistNameException extends InvalidSongException {
}