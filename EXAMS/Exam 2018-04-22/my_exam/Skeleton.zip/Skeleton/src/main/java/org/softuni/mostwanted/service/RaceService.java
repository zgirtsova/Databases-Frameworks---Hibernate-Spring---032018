package org.softuni.mostwanted.service;

public interface RaceService {
}
