package org.softuni.mostwanted.service;

import org.softuni.mostwanted.domain.dto.CarsImportJSONDto;
import org.softuni.mostwanted.domain.dto.RacersImportJSONDto;

public interface CarService {
    void create(CarsImportJSONDto carDto);
}
