package org.softuni.mostwanted.domain.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;


@XmlRootElement(name = "race-entries")
@XmlAccessorType(XmlAccessType.FIELD)
public class RaceEntriesImportXMLDto {

    @XmlElement(name = "race-entry")
    private List<RaceEntryImportXMLDto> raceEntryImportXMLDtos;

    public RaceEntriesImportXMLDto() {
        this.seRaceEntries(new ArrayList<>());
    }

    public List<RaceEntryImportXMLDto> getRaceEntryImportXMLDtos() {
        return this.raceEntryImportXMLDtos;
    }

    public void seRaceEntries(List<RaceEntryImportXMLDto> raceEntries) {
        this.raceEntryImportXMLDtos = raceEntries;
    }
}
