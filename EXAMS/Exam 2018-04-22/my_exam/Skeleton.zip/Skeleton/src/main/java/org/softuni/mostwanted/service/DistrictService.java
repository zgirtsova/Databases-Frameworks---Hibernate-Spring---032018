package org.softuni.mostwanted.service;

import org.softuni.mostwanted.domain.dto.DistrictImportJSONDto;
import org.softuni.mostwanted.domain.dto.TownImportJSONDto;

public interface DistrictService {
    void create(DistrictImportJSONDto districtDto);
}
