package org.softuni.mostwanted.service;

import org.softuni.mostwanted.domain.dto.RacersImportJSONDto;
import org.softuni.mostwanted.domain.dto.TownImportJSONDto;

public interface RacerService {

    void create(RacersImportJSONDto racerDto);
}
