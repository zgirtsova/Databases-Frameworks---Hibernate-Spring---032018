package org.softuni.mostwanted.service;

import org.softuni.mostwanted.domain.dto.RaceEntriesImportXMLDto;
import org.softuni.mostwanted.domain.dto.RaceEntryImportXMLDto;

public interface RaceEntryService {

    void create(RaceEntryImportXMLDto raceEntryImportXMLDto);
}
