package org.softuni.mostwanted.domain.dto;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.softuni.mostwanted.domain.entities.Car;
import org.softuni.mostwanted.domain.entities.Town;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

public class RacersImportJSONDto implements Serializable {


    @Expose
    private String name;

    @Expose
    private int age;

    @Expose
    private float bounty;

    @Expose
    @SerializedName(value = "townName")
    private String homeTown;

    public RacersImportJSONDto() {
    }

    public RacersImportJSONDto(String name, int age, float bounty, String homeTown) {
        this.name = name;
        this.age = age;
        this.bounty = bounty;
        this.homeTown = homeTown;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getBounty() {
        return bounty;
    }

    public void setBounty(float bounty) {
        this.bounty = bounty;
    }

    public String getHomeTown() {
        return homeTown;
    }

    public void setHomeTown(String homeTown) {
        this.homeTown = homeTown;
    }
}
