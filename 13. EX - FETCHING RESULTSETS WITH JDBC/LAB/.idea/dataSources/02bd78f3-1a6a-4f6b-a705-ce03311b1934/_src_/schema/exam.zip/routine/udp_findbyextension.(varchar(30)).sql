CREATE PROCEDURE udp_findbyextension(IN extension VARCHAR(30))
  BEGIN
	SELECT f.id, f.name, CONCAT(f.size,'KB')
	FROM files AS f
	WHERE SUBSTRING_INDEX(f.name,'.',-1) = `extension`
	ORDER BY f.id ASC;
END;
