CREATE PROCEDURE udp_commit(IN username VARCHAR(30), IN password VARCHAR(30), IN message VARCHAR(255), IN issue_id INT)
  BEGIN
	START TRANSACTION;
	
		IF
			`username` NOT IN (SELECT u.username FROM `users` AS u)
		THEN
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No such User!';
			ROLLBACK;
		ELSEIF
			`password` != (SELECT u.password FROM `users` AS u WHERE u.username = `username`)
		THEN
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Password is incorrect!';
			ROLLBACK;
		ELSEIF
			`issue_id` NOT IN (SELECT i.id FROM `issues` AS i)
		THEN
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The issue thas not exists!';
			ROLLBACK;
		ELSE
					INSERT INTO `commits` (`message`, `issue_id`, `repository_id`, `contributor_id`)
					VALUES(`message`, 
						 `issue_id`, 
						 (SELECT i.repository_id FROM issues AS i WHERE i.id = `issue_id`),
						 (SELECT u.id FROM users AS u WHERE u.username = `username`)
					);
				
					UPDATE issues AS i
					SET i.issue_status = 'closed'
					WHERE i.id = `issue_id`;
			COMMIT;
		END IF;
END;
