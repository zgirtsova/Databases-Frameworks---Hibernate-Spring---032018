CREATE VIEW rw_pw AS
  SELECT
    `w1`.`first_name`     AS `host_wizzard`,
    `w1`.`deposit_amount` AS `host_wizzard_deposit`,
    `w2`.`first_name`     AS `guest_wizzard`,
    `w2`.`deposit_amount` AS `guest_wizzard_deposit`
  FROM `gringotts`.`wizzard_deposits` `w1`
    JOIN `gringotts`.`wizzard_deposits` `w2`
  WHERE ((`w1`.`id` + 1) = `w2`.`id`);
