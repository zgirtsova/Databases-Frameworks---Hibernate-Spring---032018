CREATE VIEW vasdf AS
  SELECT
    `w`.`deposit_group`        AS `deposit_group`,
    avg(`w`.`magic_wand_size`) AS `minavg`
  FROM `gringotts`.`wizzard_deposits` `w`
  GROUP BY `w`.`deposit_group`;
