CREATE VIEW v_cur AS
  (SELECT
     `geography`.`countries`.`continent_code`       AS `continent_code`,
     `geography`.`countries`.`currency_code`        AS `currency_code`,
     count(`geography`.`countries`.`currency_code`) AS `currency_usage`
   FROM `geography`.`countries`
   GROUP BY `geography`.`countries`.`continent_code`, `geography`.`countries`.`currency_code`
   HAVING (count(`geography`.`countries`.`currency_code`) > 1));
