CREATE PROCEDURE usp_employees_promotion(IN department_name VARCHAR(50))
  BEGIN
UPDATE employees AS e
JOIN departments AS d
ON e.department_id = d.department_id
SET e.salary = 1.05*e.salary
WHERE d.name = department_name;
END;
