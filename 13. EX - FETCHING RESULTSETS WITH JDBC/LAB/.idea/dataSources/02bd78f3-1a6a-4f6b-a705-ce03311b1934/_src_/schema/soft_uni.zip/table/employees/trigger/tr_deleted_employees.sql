CREATE TRIGGER tr_deleted_employees
AFTER DELETE ON employees
FOR EACH ROW
  BEGIN
INSERT INTO deleted_employees(employee_id, first_name, middle_name, last_name, job_title, department_id, salary)
VALUES(OLD.employee_id, OLD.first_name, OLD.middle_name, OLD.last_name, OLD.job_title, OLD.department_id, OLD.salary);
END;
